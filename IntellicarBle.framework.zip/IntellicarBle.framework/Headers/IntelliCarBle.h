//
//  IntelliCarBle.h
//  IntelliCarBle
//
//  Created by Apple on 23/11/18.
//  Copyright © 2018 Intellicar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TerminalIO.h"
//#import "TIO.h"
//! Project version number for IntelliCarBle.
FOUNDATION_EXPORT double IntelliCarBleVersionNumber;

//! Project version string for IntelliCarBle.
FOUNDATION_EXPORT const unsigned char IntelliCarBleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IntelliCarBle/PublicHeader.h>

